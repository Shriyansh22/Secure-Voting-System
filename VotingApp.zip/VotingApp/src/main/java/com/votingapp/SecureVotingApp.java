package com.votingapp;

import com.fazecast.jSerialComm.*;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.AudioClip;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.mindrot.jbcrypt.BCrypt;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

public class SecureVotingApp extends Application {
    private final Path dataPath = Paths.get("VotingData");
    private final Gson gson = new Gson();
    private Map<String, Object> config = new HashMap<>();
    private final Map<String, Candidate> candidates = new HashMap<>();
    private SerialPort serialPort;
    private AudioClip voteSound;
    
    // UI Components
    private BarChart<String, Number> barChart;
    private PieChart pieChart;
    private Label clockLabel;
    private Label statusLabel;
    private Label totalVotesLabel;
    private Stage primaryStage;
    private final SimpleIntegerProperty totalVotes = new SimpleIntegerProperty(0);
    private final StringBuilder serialBuffer = new StringBuilder();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void init() throws Exception {
        Files.createDirectories(dataPath.resolve("images"));
        verifyResources();
        loadConfig();
        loadCandidates();
        debugPrintCandidates();
    }

    private void debugPrintCandidates() {
        System.out.println("=== Loaded Candidates ===");
        candidates.forEach((id, candidate) -> 
            System.out.printf("- ID: %s | Name: %-15s | Votes: %d%n", 
                id, candidate.name, candidate.votes)
        );
    }

    private void verifyResources() {
        checkResource("/default.png");
        checkResource("/vote.wav");
    }

    private void checkResource(String path) {
        if (getClass().getResource(path) == null) {
            System.err.println("CRITICAL: Missing resource - " + path);
        }
    }

    @Override
    public void start(Stage primaryStage) {
    this.primaryStage = primaryStage;
    
    // Load application icon - FIXED VERSION
    try {
        InputStream iconStream = getClass().getResourceAsStream("/icons/voting_icon.png");
        if (iconStream != null) {
            Image icon = new Image(iconStream);
            this.primaryStage.getIcons().clear();
            this.primaryStage.getIcons().add(icon);
            System.out.println("Successfully loaded application icon");
        } else {
            System.err.println("Icon file not found in resources");
        }
    } catch (Exception e) {
        System.err.println("Error loading icon: " + e.getMessage());
    }

    if (Boolean.TRUE.equals(config.get("firstRun"))) {
        showPasswordSetup();
    } else {
        showPortSelection();
    }
}

    @Override
    public void stop() {
    try {
        // Only save current votes, don't reset them
        saveCandidates();
        
        // Serial port cleanup
        if (serialPort != null) {
            if (serialPort.isOpen()) {
                serialPort.closePort();
                System.out.println("Serial port closed successfully");
            }
            serialPort = null; // Help garbage collection
        }
        
        // Clean up media resources
        if (voteSound != null) {
            voteSound.stop();
        }
    } catch (Exception e) {
        System.err.println("Shutdown error: " + e.getMessage());
        e.printStackTrace();
    }
}

    // Password Setup UI
    private void showPasswordSetup() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25));

        PasswordField pw = new PasswordField();
        Button saveBtn = new Button("Save Password");
        
        grid.add(new Label("Set Admin Password:"), 0, 0);
        grid.add(pw, 1, 0);
        grid.add(saveBtn, 1, 1);

        saveBtn.setOnAction(e -> {
            if (!pw.getText().isEmpty()) {
                config.put("passwordHash", BCrypt.hashpw(pw.getText(), BCrypt.gensalt()));
                config.put("firstRun", false);
                saveConfig();
                showPortSelection();
            }
        });

        Scene scene = new Scene(grid, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Initial Setup");
        primaryStage.show();
    }

    // Port Selection UI
    private void showPortSelection() {
        // Add null safety check
        if (primaryStage == null) {
            showAlert("Fatal Error", "Application window not initialized");
            Platform.exit();
            return;
        }

        ComboBox<String> portBox = new ComboBox<>();
        Button connectBtn = new Button("Connect");
        VBox box = new VBox(20, 
            new Label("Select Serial Port:"), 
            portBox, 
            connectBtn
        );
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(20));

        // Populate port list
        SerialPort[] ports = SerialPort.getCommPorts();
        if (ports.length == 0) {
            showAlert("No Ports", "No serial ports detected!");
            return;
        }
        Arrays.stream(ports).forEach(p -> portBox.getItems().add(p.getSystemPortName()));

        connectBtn.setOnAction(e -> {
            if (portBox.getValue() != null) {
                if (connectToPort(portBox.getValue())) {
                    showMainUI();
                } else {
                    showAlert("Connection Failed", "Could not connect to port");
                }
            }
        });

        // Configure and show stage
        primaryStage.setScene(new Scene(box, 300, 200));
        primaryStage.setTitle("Port Selection");
        primaryStage.show();
    }

    // Serial Port Handling
    private boolean connectToPort(String portName) {
        serialPort = SerialPort.getCommPort(portName);
        serialPort.setBaudRate(9600);
        
        if (serialPort.openPort()) {
            setupPortListener();
            return true;
        }
        return false;
    }

    private void setupPortListener() {
        serialPort.addDataListener(new SerialPortDataListener() {
            @Override
            public int getListeningEvents() { 
                return SerialPort.LISTENING_EVENT_DATA_AVAILABLE; 
            }

            @Override
            public void serialEvent(SerialPortEvent event) {
                try {
                    byte[] buffer = new byte[serialPort.bytesAvailable()];
                    serialPort.readBytes(buffer, buffer.length);
                    String input = new String(buffer, StandardCharsets.UTF_8);
                    serialBuffer.append(input);
                    
                    int index;
                    while ((index = serialBuffer.indexOf("\n")) != -1) {
                        String message = serialBuffer.substring(0, index).trim();
                        serialBuffer.delete(0, index + 1);
                        Platform.runLater(() -> processVote(message));
                    }
                } catch (Exception e) {
                    Platform.runLater(() -> 
                        statusLabel.setText("Serial Error: " + e.getMessage()));
                }
            }
        });
    }

    // Vote Processing
    private void processVote(String input) {
        try {
            if (candidates.containsKey(input)) {
                Candidate c = candidates.get(input);
                c.setVotes(c.votesProperty.get() + 1);
                totalVotes.set(totalVotes.get() + 1);
                updateCharts();
                playVoteSound();
                statusLabel.setText("Vote recorded for " + c.name);
            } else if (input.equals("RESET")) {
                resetVotes();
            } else {
                statusLabel.setText("Invalid vote: " + input);
            }
        } catch (Exception e) {
            showAlert("Voting Error", "Error processing vote: " + e.getMessage());
        }
    }

    // Main UI Components
    private void showMainUI() {
        System.out.println("\n=== BUILDING MAIN UI ===");
        System.out.println("Active candidates: " + candidates.size());
        
        BorderPane root = new BorderPane();
        
        // Clock Setup
        clockLabel = new Label();
        startClock();
        
        // Toolbar Setup
        ToolBar toolbar = new ToolBar(
            createButton("Reset Votes", this::resetVotes),
            createButton("Export Results", this::exportResults),
            createButton("Add Candidate", this::showAddCandidateDialog)
        );
        
        // Main Content Area
        VBox center = new VBox(20);
        center.setPadding(new Insets(20));
        ScrollPane scrollPane = new ScrollPane(center);
        scrollPane.setFitToWidth(true);
        
        // Force UI Refresh
        center.getChildren().setAll(
            createCharts(),
            createCandidateGrid()
        );

        // Status Bar
        totalVotesLabel = new Label();
        totalVotesLabel.textProperty().bind(totalVotes.asString("Total Votes: %d"));
        HBox statusBar = new HBox(10, 
            clockLabel,
            statusLabel = new Label("System Ready"), 
            totalVotesLabel
        );
        statusBar.setPadding(new Insets(10));
        statusBar.setAlignment(Pos.CENTER_LEFT);

        // Assemble UI
        root.setTop(toolbar);
        root.setCenter(scrollPane);
        root.setBottom(statusBar);

        Scene scene = new Scene(root, 1200, 800);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Secure Voting System");
        
        // Final UI Refresh
        Platform.runLater(() -> {
            updateCharts();
            primaryStage.show();
            System.out.println("=== UI RENDER COMPLETE ===");
        });
    }

    // Chart Components
    private Node createCharts() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Vote Distribution");
        barChart.setAnimated(false);
        barChart.setCategoryGap(20);
        
        pieChart = new PieChart();
        pieChart.setTitle("Vote Percentage");
        pieChart.setLegendVisible(false);
        
        updateCharts();
        
        HBox charts = new HBox(20, barChart, pieChart);
        charts.setPadding(new Insets(20));
        return charts;
    }

    private void updateCharts() {
        Platform.runLater(() -> {
            try {
                barChart.getData().clear();
                pieChart.getData().clear();

                XYChart.Series<String, Number> series = new XYChart.Series<>();
                ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();

                candidates.values().forEach(c -> {
                    series.getData().add(new XYChart.Data<>(c.name, c.votesProperty.get()));
                    pieData.add(new PieChart.Data(
                        c.name + " (" + c.votesProperty.get() + ")", 
                        c.votesProperty.get()
                    ));
                });

                barChart.getData().add(series);
                pieChart.setData(pieData);
                System.out.println("Charts updated successfully");
            } catch (Exception e) {
                System.err.println("Chart update error: " + e.getMessage());
            }
        });
    }

    // Candidate Grid
    private GridPane createCandidateGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setPadding(new Insets(20));
        grid.setAlignment(Pos.CENTER);

        if (candidates.isEmpty()) {
            Label warning = new Label("No candidates available!\nAdd candidates through the admin menu.");
            warning.setStyle("-fx-font-size: 16; -fx-text-fill: #cc0000;");
            grid.add(warning, 0, 0);
            return grid;
        }

        int col = 0, row = 0;
        for (Candidate c : candidates.values()) {
            System.out.println("Adding candidate to grid: " + c.id);
            grid.add(createCandidateCard(c), col++, row);
            if (col > 2) {
                col = 0;
                row++;
            }
        }
        return grid;
    }

    // Individual Candidate Card
    private VBox createCandidateCard(Candidate c) {
        System.out.println("Building card for: " + c.id);
        
        ImageView image = loadCandidateImage(c.id);
        image.setFitWidth(200);
        image.setFitHeight(150);
        image.setPreserveRatio(true);
        
        Label name = new Label(c.name);
        name.setStyle("-fx-font-size: 16; -fx-font-weight: bold;");
        
        Label votes = new Label();
        votes.textProperty().bind(c.votesProperty.asString("Votes: %d"));
        votes.setStyle("-fx-font-size: 14;");

        VBox card = new VBox(10, image, name, votes);
        card.setAlignment(Pos.CENTER);
        card.setStyle("-fx-border-color: #cccccc; -fx-border-radius: 5; -fx-padding: 20;");
        return card;
    }

    // Image Handling
    private ImageView loadCandidateImage(String id) {
        System.out.println("Loading image for candidate: " + id);
        try {
            Path imagePath = dataPath.resolve("images/" + id + ".jpg");
            if (Files.exists(imagePath)) {
                System.out.println("Found custom image: " + imagePath);
                return createImageView(imagePath.toUri().toString());
            }
        } catch (Exception e) {
            System.err.println("Image load error: " + e.getMessage());
        }

        URL defaultImage = getClass().getResource("/default.png");
        if (defaultImage != null) {
            System.out.println("Using default image");
            return createImageView(defaultImage.toString());
        }

        System.err.println("No images available, using fallback");
        return createFallbackImageView();
    }

    private ImageView createImageView(String url) {
        try {
            ImageView view = new ImageView(new Image(url));
            view.setFitWidth(200);
            view.setFitHeight(150);
            view.setPreserveRatio(true);
            return view;
        } catch (Exception e) {
            System.err.println("Image creation failed: " + e.getMessage());
            return createFallbackImageView();
        }
    }

    private ImageView createFallbackImageView() {
        ImageView empty = new ImageView();
        empty.setFitWidth(200);
        empty.setFitHeight(150);
        empty.setStyle("-fx-background-color: #f0f0f0;");
        return empty;
    }

    // Audio Handling
    private void playVoteSound() {
        try {
            if (voteSound == null) {
                URL soundResource = getClass().getResource("/vote.wav");
                if (soundResource == null) throw new FileNotFoundException("vote.wav not found");
                voteSound = new AudioClip(soundResource.toString());
            }
            voteSound.play();
        } catch (Exception e) {
            System.err.println("Sound error: " + e.getMessage());
        }
    }

    // Admin Functions
    private void resetVotes() {
        if (authenticateAdmin()) {
            candidates.values().forEach(c -> c.setVotes(0));
            totalVotes.set(0);
            
            // Force immediate save
            saveCandidates();
            
            // Full UI refresh
            updateCharts();
            showMainUI();
            
            statusLabel.setText("Votes reset successfully");
            System.out.println("Votes reset and saved"); // Add verification
        }
    }

    private boolean authenticateAdmin() {
        PasswordField pf = new PasswordField();
        Alert dialog = new Alert(Alert.AlertType.CONFIRMATION);
        dialog.setTitle("Admin Authentication");
        dialog.setHeaderText("Enter Admin Password");
        dialog.getDialogPane().setContent(new HBox(10, new Label("Password:"), pf));
        
        Optional<ButtonType> result = dialog.showAndWait();
        return result.isPresent() && 
               result.get() == ButtonType.OK && 
               BCrypt.checkpw(pf.getText(), (String) config.get("passwordHash"));
    }

    private void exportResults() {
        if (authenticateAdmin()) {
            try (Writer writer = Files.newBufferedWriter(dataPath.resolve("results.txt"))) {
                writer.write("Voting Results - " + 
                    LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + "\n\n");
                
                candidates.values().stream()
                    .sorted((a, b) -> Integer.compare(b.votesProperty.get(), a.votesProperty.get()))
                    .forEach(c -> {
                        try {
                            double percentage = totalVotes.get() == 0 ? 0 : 
                                100.0 * c.votesProperty.get() / totalVotes.get();
                            writer.write(String.format("%-20s: %d votes (%.1f%%)%n", 
                                c.name, c.votesProperty.get(), percentage));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                
                writer.write("\nTotal Votes: " + totalVotes.get());
                statusLabel.setText("Results exported successfully");
            } catch (IOException e) {
                showAlert("Export Failed", "Could not save results: " + e.getMessage());
            }
        }
    }

    // Candidate Management
    private void showAddCandidateDialog() {
        if (!authenticateAdmin()) return;

        Dialog<Candidate> dialog = new Dialog<>();
        dialog.setTitle("Add New Candidate");
        dialog.setHeaderText("Enter Candidate Details");

        TextField idField = new TextField();
        TextField nameField = new TextField();
        FileChooser fileChooser = new FileChooser();
        AtomicReference<File> imageFile = new AtomicReference<>();

        Button browseBtn = new Button("Browse Image");
        browseBtn.setOnAction(e -> {
            File file = fileChooser.showOpenDialog(primaryStage);
            if (file != null) {
                imageFile.set(file);
                browseBtn.setText(file.getName());
            }
        });

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.addRow(0, new Label("ID:"), idField);
        grid.addRow(1, new Label("Name:"), nameField);
        grid.addRow(2, new Label("Image:"), browseBtn);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                Candidate c = new Candidate(
                    idField.getText().trim(),
                    nameField.getText().trim()
                );
                if (imageFile.get() != null) {
                    try {
                        Path dest = dataPath.resolve("images/" + c.id + ".jpg");
                        Files.copy(imageFile.get().toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
                    } catch (IOException e) {
                        showAlert("Image Error", "Could not save candidate image: " + e.getMessage());
                    }
                }
                return c;
            }
            return null;
        });

        Optional<Candidate> result = dialog.showAndWait();
        result.ifPresent(c -> {
            candidates.put(c.id, c);
            saveCandidates();
            updateCharts();
            showMainUI(); // Force full refresh
        });
    }

    // Utility Methods
    private Button createButton(String text, Runnable action) {
        Button btn = new Button(text);
        btn.setStyle("-fx-font-size: 14; -fx-padding: 5 15;");
        btn.setOnAction(e -> action.run());
        return btn;
    }

    private void startClock() {
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> 
            clockLabel.setText(LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("HH:mm:ss dd-MMM-yyyy"))
            )));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    // Configuration Management
    private void loadConfig() throws IOException {
        Path configFile = dataPath.resolve("config.json");
        if (Files.exists(configFile)) {
            config = gson.fromJson(Files.readString(configFile), 
                new TypeToken<Map<String, Object>>(){}.getType());
        } else {
            config.put("firstRun", true);
        }
    }

    private void saveConfig() {
        try {
            Files.writeString(dataPath.resolve("config.json"), 
                gson.toJson(config), StandardOpenOption.CREATE);
        } catch (IOException e) {
            showAlert("Config Error", "Failed to save configuration: " + e.getMessage());
        }
    }

    // Candidate Data Management
    private void loadCandidates() throws IOException {
        Path candidatesFile = dataPath.resolve("candidates.json");
        if (Files.exists(candidatesFile)) {
            try {
                List<Candidate> loaded = gson.fromJson(
                    Files.readString(candidatesFile),
                    new TypeToken<ArrayList<Candidate>>(){}.getType()
                );
                loaded.forEach(c -> {
                    c.votesProperty = new SimpleIntegerProperty(c.votes);
                    candidates.put(c.id, c);
                });
                System.out.println("Loaded " + loaded.size() + " candidates from file");
            } catch (JsonSyntaxException e) {
                System.err.println("Corrupted candidates file. Resetting...");
                initializeDefaultCandidates();
            }
        } else {
            System.out.println("No candidates file found, initializing defaults");
            initializeDefaultCandidates();
        }
    }

    private void initializeDefaultCandidates() {
        System.out.println("Initializing default candidates");
        Arrays.asList(
            new Candidate("A", "Anupam", 0),
            new Candidate("B", "Shivanand", 0),
            new Candidate("C", "Anand", 0)
        ).forEach(c -> {
            c.votesProperty = new SimpleIntegerProperty(c.votes);
            candidates.put(c.id, c);
        });
        saveCandidates();
    }

    private void saveCandidates() {
        try {
            List<Candidate> toSave = new ArrayList<>(candidates.values());
            Files.writeString(
                dataPath.resolve("candidates.json"),
                gson.toJson(toSave),
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING
            );
            System.out.println("Saved " + toSave.size() + " candidates");
        } catch (IOException e) {
            showAlert("Save Error", "Could not save candidates: " + e.getMessage());
        }
    }

    // Candidate Class
    private static class Candidate implements Serializable {
        String id;
        String name;
        transient SimpleIntegerProperty votesProperty;
        int votes;

        Candidate(String id, String name, int votes) {
            this.id = id;
            this.name = name;
            this.votes = votes;
            this.votesProperty = new SimpleIntegerProperty(votes);
        }

        Candidate(String id, String name) {
            this(id, name, 0);
        }

        public void setVotes(int votes) {
            this.votes = votes;
            this.votesProperty.set(votes);
        }

        private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
            ois.defaultReadObject();
            this.votesProperty = new SimpleIntegerProperty(this.votes);
        }
    }

    // Alert System
    private void showAlert(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}