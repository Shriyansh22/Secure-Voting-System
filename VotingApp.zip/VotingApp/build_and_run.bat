@echo off
rem === Build and Run SecureVotingApp ===

cd /d "%~dp0"

rem ==== Paths ====
set JAVAFX_LIB="C:\javafx-sdk-21\lib"
set OUT_DIR=out
set SRC_DIR=src\main\java
set LIBS=libs\gson-2.8.9.jar;libs\jbcrypt-0.4.jar;libs\jSerialComm-2.11.0.jar

rem ==== Create output directory if it doesn't exist ====
if not exist %OUT_DIR% mkdir %OUT_DIR%

rem ==== Compile all Java source files ====
echo Compiling sources...
javac ^
  -d %OUT_DIR% ^
  -cp "%LIBS%" ^
  --module-path %JAVAFX_LIB% ^
  --add-modules javafx.controls,javafx.fxml,javafx.media ^
  -Xlint:none ^
  %SRC_DIR%\com\votingapp\*.java
xcopy /Y /I src\main\resources\default.png out\
xcopy /Y /I src\main\resources\vote.wav out\

if errorlevel 1 (
    echo Compilation failed.
    pause
    exit /b 1
)

rem ==== Run the application ====
echo Running application...
java ^
  --module-path %JAVAFX_LIB% ^
  --add-modules javafx.controls,javafx.fxml,javafx.media ^
  --add-opens javafx.graphics/com.sun.javafx.tk.quantum=ALL-UNNAMED ^
  -cp "%OUT_DIR%;%LIBS%" ^
  com.votingapp.SecureVotingApp
xcopy /Y /I src\main\resources\default.png out\
xcopy /Y /I src\main\resources\vote.wav out\

pause
