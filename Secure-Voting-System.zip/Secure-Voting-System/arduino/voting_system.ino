/*
 * ============================================================
 * Secure Bluetooth-Based Voting System — Arduino Firmware
 * ============================================================
 * Author  : Shriyanshu Kumar Chaudhary
 * College : Faculty of Technology, University of Delhi
 *
 * Hardware:
 *   - Arduino Uno
 *   - Push buttons → D2 (Candidate A), D3 (B), D4 (C)
 *   - LEDs         → A0 (A), A1 (B), A2 (C)
 *   - Tamper LED   → A3
 *   - Buzzer       → D12
 *   - TM1637 displays:
 *       A: CLK=D6, DIO=D7
 *       B: CLK=D8, DIO=D9
 *       C: CLK=D10, DIO=D11
 *   - HC-05 Bluetooth → default Serial (TX/RX)
 * ============================================================
 */

#include <TM1637Display.h>

// ---- Pin Definitions ----
#define CANDIDATE_A   2
#define CANDIDATE_B   3
#define CANDIDATE_C   4
#define LED_A         A0
#define LED_B         A1
#define LED_C         A2
#define TAMPER_LED    A3
#define BUZZER        12

// TM1637 display pins
#define CLK_A   6
#define DIO_A   7
#define CLK_B   8
#define DIO_B   9
#define CLK_C   10
#define DIO_C   11

// ---- Display objects ----
TM1637Display displayA(CLK_A, DIO_A);
TM1637Display displayB(CLK_B, DIO_B);
TM1637Display displayC(CLK_C, DIO_C);

// ---- State ----
int votesA = 0, votesB = 0, votesC = 0;
unsigned long lastVoteTime = 0;
const unsigned long DEBOUNCE_DELAY = 1000; // 1 second between votes
bool voteLock = false;
bool sessionActive = false;

// ============================================================
// Setup
// ============================================================
void setup() {
  Serial.begin(9600); // HC-05 Bluetooth

  // Input pins
  pinMode(CANDIDATE_A, INPUT);
  pinMode(CANDIDATE_B, INPUT);
  pinMode(CANDIDATE_C, INPUT);

  // Output pins
  pinMode(LED_A,      OUTPUT);
  pinMode(LED_B,      OUTPUT);
  pinMode(LED_C,      OUTPUT);
  pinMode(TAMPER_LED, OUTPUT);
  pinMode(BUZZER,     OUTPUT);

  // Init displays
  displayA.setBrightness(0x0f);
  displayB.setBrightness(0x0f);
  displayC.setBrightness(0x0f);
  displayA.showNumberDec(0, true);
  displayB.showNumberDec(0, true);
  displayC.showNumberDec(0, true);

  // Startup beep
  tone(BUZZER, 4000, 200);
  delay(250);
  noTone(BUZZER);

  Serial.println("SYSTEM:READY");
}

// ============================================================
// Main Loop
// ============================================================
void loop() {
  // ---- Handle Bluetooth Commands ----
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    handleCommand(cmd);
  }

  if (!sessionActive) return;

  // ---- Read button states ----
  bool aPressed = digitalRead(CANDIDATE_A) == HIGH;
  bool bPressed = digitalRead(CANDIDATE_B) == HIGH;
  bool cPressed = digitalRead(CANDIDATE_C) == HIGH;
  int  activeCount = (int)aPressed + (int)bPressed + (int)cPressed;

  // ---- Tamper Detection (multiple buttons pressed) ----
  if (activeCount > 1) {
    digitalWrite(TAMPER_LED, HIGH);
    // Alert buzzer: 3 rapid beeps
    for (int i = 0; i < 3; i++) {
      tone(BUZZER, 3000, 100);
      delay(120);
      noTone(BUZZER);
    }
    Serial.println("ALERT:TAMPER_DETECTED");
    // Reset all counts
    votesA = votesB = votesC = 0;
    displayA.showNumberDec(0, true);
    displayB.showNumberDec(0, true);
    displayC.showNumberDec(0, true);
    digitalWrite(TAMPER_LED, LOW);
    sessionActive = false;
    return;
  }

  // ---- Voting (with debounce) ----
  if ((millis() - lastVoteTime > DEBOUNCE_DELAY) && !voteLock) {
    if (aPressed) {
      votesA++;
      handleVote('A', votesA, LED_A, displayA);
    } else if (bPressed) {
      votesB++;
      handleVote('B', votesB, LED_B, displayB);
    } else if (cPressed) {
      votesC++;
      handleVote('C', votesC, LED_C, displayC);
    }
  }

  // Release lock when all buttons released
  if (!aPressed && !bPressed && !cPressed) {
    voteLock = false;
  }
}

// ============================================================
// Handle a single vote
// ============================================================
void handleVote(char candidateId, int count,
                int ledPin, TM1637Display& disp) {
  disp.showNumberDec(count, true);

  // Confirmation feedback
  digitalWrite(ledPin, HIGH);
  tone(BUZZER, 4000, 150);
  delay(150);
  noTone(BUZZER);
  digitalWrite(ledPin, LOW);

  // Send to JavaFX via Bluetooth
  Serial.print(candidateId);
  Serial.print('\n');

  lastVoteTime = millis();
  voteLock     = true;
}

// ============================================================
// Handle Bluetooth Commands from JavaFX
// ============================================================
void handleCommand(String cmd) {
  if (cmd == "START_SESSION") {
    sessionActive = true;
    Serial.println("SESSION:STARTED");

  } else if (cmd == "STOP_SESSION") {
    sessionActive = false;
    sendCounts();
    Serial.println("SESSION:STOPPED");

  } else if (cmd == "RESET_VOTES") {
    votesA = votesB = votesC = 0;
    displayA.showNumberDec(0, true);
    displayB.showNumberDec(0, true);
    displayC.showNumberDec(0, true);
    Serial.println("VOTES:RESET");

  } else if (cmd == "GET_COUNTS") {
    sendCounts();

  } else if (cmd == "PING") {
    Serial.println("PONG");
  }
}

void sendCounts() {
  Serial.print("COUNTS:");
  Serial.print(votesA); Serial.print(",");
  Serial.print(votesB); Serial.print(",");
  Serial.println(votesC);
}
