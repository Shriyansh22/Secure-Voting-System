# 🗳 Secure Bluetooth-Based Voting System

![Platform](https://img.shields.io/badge/Platform-Arduino-blue)
![Language](https://img.shields.io/badge/Language-Java%20%7C%20C%2B%2B-orange)
![Framework](https://img.shields.io/badge/Framework-JavaFX-green)
![Status](https://img.shields.io/badge/Status-Completed-brightgreen)

> A secure embedded voting system integrating Arduino hardware with a JavaFX desktop dashboard for real-time vote monitoring via Bluetooth.

**Author:** Shriyanshu Kumar Chaudhary  
**Institution:** Faculty of Technology, University of Delhi | B.Tech ECE

---

## 📌 Features

- ✅ Real-time voting via capacitive push buttons
- ✅ TM1637 7-segment displays for live vote counts per candidate
- ✅ Bluetooth (HC-05) data transmission to JavaFX dashboard
- ✅ BCrypt-secured admin authentication
- ✅ Tamper detection — flags simultaneous button presses
- ✅ Bar chart + Pie chart visualizations
- ✅ Export results as JSON
- ✅ 100% vote accuracy | <200ms end-to-end latency

---

## 🏗️ System Architecture

```
Push Buttons (A / B / C)
     ↓
Arduino Uno
  → Debounce + Tamper Detection
  → TM1637 Display Update
  → HC-05 Bluetooth Serial TX
     ↓
JavaFX Dashboard (PC)
  → Serial listener (jSerialComm)
  → Live bar + pie chart update
  → BCrypt admin panel
  → JSON export
```

---

## 🔌 Hardware Wiring

| Component      | Arduino Pin |
|----------------|-------------|
| Button A       | D2          |
| Button B       | D3          |
| Button C       | D4          |
| LED A          | A0          |
| LED B          | A1          |
| LED C          | A2          |
| Tamper LED     | A3          |
| Buzzer         | D12         |
| TM1637-A CLK   | D6          |
| TM1637-A DIO   | D7          |
| TM1637-B CLK   | D8          |
| TM1637-B DIO   | D9          |
| TM1637-C CLK   | D10         |
| TM1637-C DIO   | D11         |
| HC-05 TX       | RX (D0)     |
| HC-05 RX       | TX (D1)     |

---

## 📁 Project Structure

```
Secure-Voting-System/
├── arduino/
│   └── voting_system.ino              # Arduino firmware
├── javafx/
│   └── src/main/java/voting/
│       └── VotingApp.java             # JavaFX desktop app
└── README.md
```

---

## 🚀 Getting Started

### 1. Arduino
1. Open `arduino/voting_system.ino` in Arduino IDE
2. Install libraries: `TM1637Display`
3. Upload to Arduino Uno

### 2. JavaFX App
Add these to your project dependencies:
```xml
<dependency>
    <groupId>com.fazecast</groupId>
    <artifactId>jSerialComm</artifactId>
    <version>2.10.4</version>
</dependency>
<dependency>
    <groupId>org.mindrot</groupId>
    <artifactId>jbcrypt</artifactId>
    <version>0.4</version>
</dependency>
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.10.1</version>
</dependency>
```
Run `VotingApp.java` — select the correct COM port when prompted.

---

## 📊 Performance Results

| Parameter        | Result                 |
|------------------|------------------------|
| Vote Accuracy    | 100% (40,000 cycles)   |
| End-to-End Latency | < 200 ms            |
| Tamper Detection | 100% rate, 68ms response |
| Serial Reliability | 100% @9600 baud      |

---

## 🔐 Security

- **BCrypt** hashed admin password (default: `admin123` — change before use!)
- **Tamper detection** resets all votes and alerts if multiple buttons pressed
- **Debounce** prevents double-counting

---

## 📜 License

MIT License — free to use and modify with attribution.
