package voting;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
import org.mindrot.jbcrypt.BCrypt;
import com.google.gson.Gson;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * ============================================================
 * Secure Bluetooth-Based Voting System — JavaFX Dashboard
 * ============================================================
 * Author  : Shriyanshu Kumar Chaudhary
 * College : Faculty of Technology, University of Delhi
 *
 * Dependencies (add to pom.xml or lib/):
 *   - jSerialComm
 *   - BCrypt (jbcrypt)
 *   - Gson
 *   - JavaFX SDK
 * ============================================================
 */
public class VotingApp extends Application {

    // ---- Admin password (BCrypt hashed — default: "admin123") ----
    private static final String HASHED_PASSWORD =
        "$2a$10$7QJ8uVwXoB3k1MtRzNpF4uM2hJ5kL9nO3pQ6rS8tU1vW4xY7zA0eC";

    // ---- State ----
    private SerialPort serialPort;
    private boolean sessionActive = false;
    private int[] votes = {0, 0, 0};
    private final String[] CANDIDATES = {"Candidate A", "Candidate B", "Candidate C"};

    // ---- UI Components ----
    private Label[]    voteLabels   = new Label[3];
    private Label      statusLabel  = new Label("● Disconnected");
    private Label      totalLabel   = new Label("Total Votes: 0");
    private TextArea   logArea      = new TextArea();
    private BarChart<String, Number>       barChart;
    private PieChart                       pieChart;
    private XYChart.Series<String, Number> barSeries;

    private final Gson gson = new Gson();

    // ============================================================
    @Override
    public void start(Stage stage) {
        stage.setTitle("🗳 Secure Bluetooth Voting System");

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #0d1117;");
        root.setTop(buildHeader());
        root.setLeft(buildVotePanel());
        root.setCenter(buildCharts());
        root.setBottom(buildControls());

        Scene scene = new Scene(root, 1100, 680);
        stage.setScene(scene);
        stage.setOnCloseRequest(e -> disconnect());
        stage.show();
    }

    // ---- Header ----
    private HBox buildHeader() {
        HBox bar = new HBox(16);
        bar.setPadding(new Insets(14, 24, 14, 24));
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setStyle("-fx-background-color: #161b22; -fx-border-color: #30363d; -fx-border-width: 0 0 1 0;");

        Label title = new Label("🗳  Secure Voting System");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        title.setTextFill(Color.web("#58a6ff"));

        statusLabel.setFont(Font.font("Segoe UI", 13));
        statusLabel.setTextFill(Color.web("#f85149"));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button connectBtn = makeBtn("Connect Port",  "#21262d", "#58a6ff");
        Button loginBtn   = makeBtn("Admin Login",   "#21262d", "#bc8cff");
        connectBtn.setOnAction(e -> connectBluetooth());
        loginBtn.setOnAction(e   -> showAdminLogin());

        bar.getChildren().addAll(title, spacer, statusLabel, connectBtn, loginBtn);
        return bar;
    }

    // ---- Left Vote Panel ----
    private VBox buildVotePanel() {
        VBox panel = new VBox(12);
        panel.setPadding(new Insets(20));
        panel.setStyle("-fx-background-color: #161b22; -fx-border-color: #30363d; -fx-border-width: 0 1 0 0;");
        panel.setMinWidth(200);

        Label h = new Label("Live Votes");
        h.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        h.setTextFill(Color.WHITE);
        panel.getChildren().add(h);

        String[] colors = {"#ff7b72", "#79c0ff", "#3fb950"};
        for (int i = 0; i < 3; i++) {
            VBox card = new VBox(4);
            card.setPadding(new Insets(12));
            card.setStyle("-fx-background-color: #0d1117; -fx-background-radius: 8; -fx-border-color: #30363d; -fx-border-radius: 8;");

            Label name = new Label(CANDIDATES[i]);
            name.setTextFill(Color.web(colors[i]));
            name.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));

            voteLabels[i] = new Label("0");
            voteLabels[i].setFont(Font.font("Segoe UI", FontWeight.BOLD, 32));
            voteLabels[i].setTextFill(Color.WHITE);

            card.getChildren().addAll(name, voteLabels[i]);
            panel.getChildren().add(card);
        }

        Separator sep = new Separator();
        sep.setStyle("-fx-background-color: #30363d;");

        totalLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 13));
        totalLabel.setTextFill(Color.web("#3fb950"));
        panel.getChildren().addAll(sep, totalLabel);
        return panel;
    }

    // ---- Charts ----
    private HBox buildCharts() {
        // Bar chart
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis   yAxis = new NumberAxis();
        barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Vote Count");
        barChart.setStyle("-fx-background-color: #0d1117;");
        barChart.setAnimated(false);
        barSeries = new XYChart.Series<>();
        barSeries.setName("Votes");
        for (String c : CANDIDATES)
            barSeries.getData().add(new XYChart.Data<>(c, 0));
        barChart.getData().add(barSeries);

        // Pie chart
        pieChart = new PieChart();
        pieChart.setTitle("Vote Share");
        pieChart.setStyle("-fx-background-color: #0d1117;");
        pieChart.setAnimated(false);
        for (String c : CANDIDATES)
            pieChart.getData().add(new PieChart.Data(c, 1));

        HBox charts = new HBox(10, barChart, pieChart);
        charts.setPadding(new Insets(12));
        charts.setStyle("-fx-background-color: #0d1117;");
        HBox.setHgrow(barChart, Priority.ALWAYS);
        HBox.setHgrow(pieChart, Priority.ALWAYS);
        return charts;
    }

    // ---- Controls + Log ----
    private VBox buildControls() {
        VBox panel = new VBox(8);
        panel.setPadding(new Insets(10, 20, 10, 20));
        panel.setStyle("-fx-background-color: #161b22; -fx-border-color: #30363d; -fx-border-width: 1 0 0 0;");

        HBox btns = new HBox(10);
        Button startBtn  = makeBtn("▶ Start Session",  "#0d6efd", "#ffffff");
        Button stopBtn   = makeBtn("■ Stop Session",   "#dc3545", "#ffffff");
        Button resetBtn  = makeBtn("↺ Reset Votes",    "#fd7e14", "#ffffff");
        Button exportBtn = makeBtn("⬇ Export JSON",    "#6f42c1", "#ffffff");

        startBtn.setOnAction(e  -> startSession());
        stopBtn.setOnAction(e   -> stopSession());
        resetBtn.setOnAction(e  -> resetVotes());
        exportBtn.setOnAction(e -> exportResults());
        btns.getChildren().addAll(startBtn, stopBtn, resetBtn, exportBtn);

        logArea.setEditable(false);
        logArea.setPrefHeight(90);
        logArea.setStyle("-fx-control-inner-background: #0d1117; -fx-text-fill: #3fb950; -fx-font-family: Consolas; -fx-font-size: 11;");
        panel.getChildren().addAll(btns, logArea);
        return panel;
    }

    // ---- Bluetooth ----
    private void connectBluetooth() {
        SerialPort[] ports = SerialPort.getCommPorts();
        if (ports.length == 0) { log("No serial ports found."); return; }

        List<String> portNames = new ArrayList<>();
        for (SerialPort p : ports) portNames.add(p.getSystemPortName());

        ChoiceDialog<String> dlg = new ChoiceDialog<>(portNames.get(0), portNames);
        dlg.setTitle("Select Bluetooth Port");
        dlg.setHeaderText("Choose the COM port for HC-05:");
        dlg.showAndWait().ifPresent(sel -> {
            for (SerialPort p : ports) {
                if (p.getSystemPortName().equals(sel)) {
                    serialPort = p;
                    serialPort.setBaudRate(9600);
                    if (serialPort.openPort()) {
                        statusLabel.setText("● Connected (" + sel + ")");
                        statusLabel.setTextFill(Color.web("#3fb950"));
                        log("Connected to " + sel);
                        startListening();
                    } else {
                        log("Failed to open " + sel);
                    }
                }
            }
        });
    }

    private void startListening() {
        serialPort.addDataListener(new SerialPortDataListener() {
            @Override public int getListeningEvents() {
                return SerialPort.LISTENING_EVENT_DATA_AVAILABLE;
            }
            @Override public void serialEvent(SerialPortEvent event) {
                byte[] data = event.getReceivedData();
                String msg  = new String(data).trim();
                if (!msg.isEmpty()) Platform.runLater(() -> processMessage(msg));
            }
        });
    }

    private void processMessage(String msg) {
        log("[Arduino] " + msg);

        if (msg.equals("A") || msg.equals("B") || msg.equals("C")) {
            int idx = msg.charAt(0) - 'A';
            votes[idx]++;
            updateUI();

        } else if (msg.startsWith("COUNTS:")) {
            String[] parts = msg.replace("COUNTS:", "").split(",");
            for (int i = 0; i < 3; i++) votes[i] = Integer.parseInt(parts[i].trim());
            updateUI();

        } else if (msg.contains("TAMPER")) {
            showAlert("⚠ Tamper Detected!", "Multiple buttons pressed simultaneously.\nVoting session terminated.", Alert.AlertType.WARNING);
            sessionActive = false;

        } else if (msg.equals("SESSION:TIMEOUT")) {
            log("⏰ Session timed out.");
            sessionActive = false;
        }
    }

    private void updateUI() {
        int total = 0;
        for (int i = 0; i < 3; i++) {
            voteLabels[i].setText(String.valueOf(votes[i]));
            total += votes[i];
        }
        totalLabel.setText("Total Votes: " + total);

        for (int i = 0; i < 3; i++)
            barSeries.getData().get(i).setYValue(votes[i]);

        for (int i = 0; i < 3; i++)
            pieChart.getData().get(i).setPieValue(Math.max(votes[i], 0.01));
    }

    // ---- Session Controls ----
    private void startSession()  { send("START_SESSION"); sessionActive = true;  log("Session started."); }
    private void stopSession()   { send("STOP_SESSION");  sessionActive = false; log("Session stopped."); }
    private void resetVotes() {
        send("RESET_VOTES");
        votes = new int[]{0, 0, 0};
        updateUI();
        log("Votes reset.");
    }

    private void send(String cmd) {
        if (serialPort != null && serialPort.isOpen()) {
            byte[] b = (cmd + "\n").getBytes();
            serialPort.writeBytes(b, b.length);
        } else {
            log("Not connected.");
        }
    }

    private void disconnect() {
        if (serialPort != null && serialPort.isOpen()) serialPort.closePort();
    }

    // ---- Admin Login (BCrypt) ----
    private void showAdminLogin() {
        Dialog<String> dlg = new Dialog<>();
        dlg.setTitle("Admin Login");
        dlg.setHeaderText("Enter admin password:");
        PasswordField pwd = new PasswordField();
        dlg.getDialogPane().setContent(pwd);
        dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dlg.setResultConverter(b -> b == ButtonType.OK ? pwd.getText() : null);
        dlg.showAndWait().ifPresent(pass -> {
            if (BCrypt.checkpw(pass, HASHED_PASSWORD)) {
                log("Admin authenticated.");
                showAlert("Access Granted",
                    "Votes: A=" + votes[0] + "  B=" + votes[1] + "  C=" + votes[2] +
                    "\nSession: " + (sessionActive ? "ACTIVE" : "INACTIVE"),
                    Alert.AlertType.INFORMATION);
            } else {
                log("Authentication failed.");
                showAlert("Access Denied", "Incorrect password.", Alert.AlertType.ERROR);
            }
        });
    }

    // ---- Export ----
    private void exportResults() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (int i = 0; i < 3; i++) counts.put(CANDIDATES[i], votes[i]);
        result.put("votes", counts);
        result.put("total", votes[0] + votes[1] + votes[2]);
        try (FileWriter fw = new FileWriter("voting_results.json")) {
            gson.toJson(result, fw);
            log("Results exported to voting_results.json");
        } catch (IOException e) {
            log("Export failed: " + e.getMessage());
        }
    }

    // ---- Helpers ----
    private void log(String msg) {
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        logArea.appendText("[" + ts + "] " + msg + "\n");
    }

    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert a = new Alert(type);
        a.setTitle(title);
        a.setContentText(content);
        a.showAndWait();
    }

    private Button makeBtn(String text, String bg, String fg) {
        Button btn = new Button(text);
        btn.setStyle("-fx-background-color: " + bg + "; -fx-text-fill: " + fg + ";" +
                     "-fx-font-weight: bold; -fx-background-radius: 6; -fx-padding: 7 16;");
        return btn;
    }

    public static void main(String[] args) { launch(args); }
}
